﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Text;

public class Dice : MonoBehaviour {

    public int numberGot;
    [SerializeField] SpriteRenderer dice;
    [SerializeField] GameObject diceAnim;
    [SerializeField] Sprite[] numberSprites;

    Coroutine _dice;

	// Update is called once per frame
	public void rollDice () {
        _dice = StartCoroutine(rollingDiceAnim());
        Client.sender.Send(Encoding.ASCII.GetBytes(numberGot.ToString()));
	}

    IEnumerator rollingDiceAnim()
    {
        yield return new WaitForEndOfFrame();
        dice.gameObject.SetActive(false);
        diceAnim.SetActive(true);
        yield return new WaitForSeconds(0.5f);

        numberGot = Random.Range(0, 6);
        dice.sprite = numberSprites[numberGot];

        dice.gameObject.SetActive(true);
        diceAnim.SetActive(false);
        yield return new WaitForEndOfFrame();

        if (_dice!=null)
        {
            StopCoroutine(_dice);
        }
    }
}
